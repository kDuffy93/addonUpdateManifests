var synth = window.speechSynthesis;
synth.cancel();
let saySentense = (sentense) => {
    return new Promise((resolve, reject) => {
        sentense = sentense.toLowerCase();
        let utterThis = new SpeechSynthesisUtterance(sentense);
        utterThis.pitch = 1;
        utterThis.rate = 1;
        synth.speak(utterThis);
        utterThis.addEventListener("end", () => {
            console.log("speaking Done");
            resolve();
        });
        utterThis.addEventListener("cancel", () => {
            removeSpeakingClasses();
            console.log(`speaking cancelled  `);
            reject();
        });
    });
};

let border = document.createElement("div");
border.id = 'border';
border.style.width = "100vw";
border.style.height = "100vh";
border.style.border = "solid 15px gray";
border.style.position = "fixed";
border.style.top = 0;
border.style.left = 0;
border.style.zIndex = 100;
border.style.pointerEvents = 'none';

let body = document.getElementsByTagName("body")[0];
body.appendChild(border);
let alreadySpoken = false;

let temp = () => {




    try {

        let border = document.getElementById("border");
        let gameName = document.getElementsByClassName("ipe-EventHeader_Fixture ")[0].textContent;
        let index;
        let indexLength;
        if (gameName.includes('vs')) {
            index = gameName.indexOf(" vs ");
            indexLength = 4;
        } else if (gameName.includes('@')) {
            index = gameName.indexOf(" @ ");
            indexLength = 3;
        } else {
            index = gameName.length;
            indexLength = 0;
        }
        let teamName1 = gameName.slice(0, index)
        let teamName2 = gameName.slice(index + indexLength)





        console.log(`${teamName1} versus ${teamName2}`);

        let field = document.getElementsByClassName("ml18-CommonAnimations_H2Text ")[0];

        if (field.textContent == "Time Out") {

            border.style.borderColor = 'red';
            if (!alreadySpoken) {
                if (!synth.speaking) {
                    saySentense(`${teamName1}`);
                    alreadySpoken = true;
                }
            }


            if (document.title == "Time Out") {
                document.title = `${teamName1}`;
            } else {
                document.title = "Time Out";
            }

        } else {
            border.style.borderColor = "green";
            alreadySpoken = false;
            document.title = `${teamName1}`;
        }
    } catch {
        console.log("No Fields loaded");
    }
};

const intervalID = setInterval(temp, 500);